Student Course Management (VS Code + Tomcat)

1. Requirements:
   - Java 17 (or 11+)
   - Maven
   - VS Code with 'Extension Pack for Java' and 'Tomcat for Java'

2. Build:
   - Open project folder in VS Code.
   - Run in terminal: mvn package
   - A WAR file will be generated under target/StudentCourseManagement-1.0-SNAPSHOT.war

3. Deploy to Tomcat (VS Code Tomcat extension):
   - Open Tomcat extension in VS Code, add local Tomcat if not added.
   - Right-click 'Tomcat Servers' -> 'Add Webapp...' -> Select the generated WAR file.
   - Start the server and open: http://localhost:8080/StudentCourseManagement/

Notes:
- CSV files are in the 'data' folder at project root.
- If links don't match context path, adjust action URLs in HTML (they assume context path /StudentCourseManagement).

package com.easwari.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.nio.file.*;
import java.util.*;

@WebServlet(name="DeleteStudentServlet", urlPatterns = {"/students/delete"})
public class DeleteStudentServlet extends HttpServlet {
    private Path dataFile() throws IOException {
        Path webapp = Paths.get(getServletContext().getRealPath("/"));
        Path projRoot = webapp.getParent().getParent();
        Path p = projRoot.resolve("data").resolve("students.csv").normalize();
        if (!Files.exists(p)) { Files.createDirectories(p.getParent()); Files.createFile(p); }
        return p;
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String roll = req.getParameter("roll");
        if(roll==null){ resp.sendRedirect(req.getContextPath()+"/students"); return; }
        Path file = dataFile();
        List<String> lines = Files.readAllLines(file);
        List<String> out = new ArrayList<>();
        for(String ln : lines){
            if(ln.trim().isEmpty()) continue;
            String[] parts = ln.split(",", -1);
            if(parts.length>1 && parts[1].equals(roll)) continue;
            out.add(ln);
        }
        Files.write(file, out);
        resp.getWriter().write("<script>alert('Deleted');window.location='"+req.getContextPath()+"/students';</script>");
    }
}

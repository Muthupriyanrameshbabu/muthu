package com.easwari.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.nio.file.*;
import java.util.*;

@WebServlet(name="EditStudentServlet", urlPatterns = {"/students/edit"})
public class EditStudentServlet extends HttpServlet {

    private Path dataFile() throws IOException {
        Path webapp = Paths.get(getServletContext().getRealPath("/"));
        Path projRoot = webapp.getParent().getParent();
        Path p = projRoot.resolve("data").resolve("students.csv").normalize();
        if (!Files.exists(p)) {
            Files.createDirectories(p.getParent());
            Files.createFile(p);
        }
        return p;
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String roll = req.getParameter("roll");
        Path file = dataFile();
        List<String> lines = Files.readAllLines(file);
        String foundLine = null;
        for(String ln : lines){
            if(ln.trim().isEmpty()) continue;
            String[] parts = ln.split(",", -1);
            if(parts.length>1 && parts[1].equals(roll)){ foundLine = ln; break; }
        }
        if(foundLine==null){ resp.sendRedirect(req.getContextPath() + "/students"); return; }
        String[] p = foundLine.split(",", -1);
        String name = p.length>0? p[0] : "";
        String dept = p.length>2? p[2] : "";
        String year = p.length>3? p[3] : "";

        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        out.println("<!doctype html><html><head><meta charset='utf-8'/><title>Edit Student</title><link rel='stylesheet' href='/StudentCourseManagement/style.css'></head><body>");
        out.println("<div class='header'>EASWARI - Edit Student</div><div class='container'>");
        out.println("<form method='post' action='"+req.getContextPath()+"/students/edit'>");
        out.println("<input type='hidden' name='origRoll' value='"+roll+"'/>");
        out.println("<label>Name</label><input name='name' value='"+escape(name)+"' required/>");
        out.println("<label>Roll</label><input name='roll' value='"+escape(roll)+"' required/>");
        out.println("<label>Department</label><input name='department' value='"+escape(dept)+"' required/>");
        out.println("<label>Year</label><input name='year' value='"+escape(year)+"' required/>");
        out.println("<div style='margin-top:10px'><button type='submit'>Update</button> <a href='"+req.getContextPath()+"/students'><button type='button'>Cancel</button></a></div></form>");
        out.println("</div></body></html>");
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String origRoll = req.getParameter("origRoll");
        String name = req.getParameter("name");
        String roll = req.getParameter("roll");
        String dept = req.getParameter("department");
        String year = req.getParameter("year");

        Path file = dataFile();
        List<String> lines = Files.readAllLines(file);
        for(int i=0;i<lines.size();i++){
            String ln = lines.get(i);
            if(ln.trim().isEmpty()) continue;
            String[] parts = ln.split(",", -1);
            if(parts.length>1 && parts[1].equals(origRoll)){
                String newline = escapeCsv(name)+","+escapeCsv(roll)+","+escapeCsv(dept)+","+escapeCsv(year);
                lines.set(i, newline);
                break;
            }
        }
        Files.write(file, lines);
        resp.getWriter().write("<script>alert('Updated');window.location='"+req.getContextPath()+"/students';</script>");
    }

    private String escape(String s){ if(s==null) return ""; return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;"); }
    private String escapeCsv(String s){ if(s==null) return ""; return s.replaceAll(","," "); }
}

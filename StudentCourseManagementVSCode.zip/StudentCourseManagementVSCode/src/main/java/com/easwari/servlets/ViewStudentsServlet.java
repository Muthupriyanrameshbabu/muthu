package com.easwari.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name="ViewStudentsServlet", urlPatterns = {"/students"})
public class ViewStudentsServlet extends HttpServlet {

    private Path dataFile() throws IOException {
        // prefer project-root data/students.csv relative to webapp
        Path webapp = Paths.get(getServletContext().getRealPath("/"));
        Path projRoot = webapp.getParent().getParent(); // target webapp/../../
        Path p = projRoot.resolve("data").resolve("students.csv").normalize();
        if (!Files.exists(p)) {
            Files.createDirectories(p.getParent());
            Files.createFile(p);
        }
        return p;
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        List<String[]> rows = new ArrayList<>();
        Path file = dataFile();
        try (BufferedReader br = Files.newBufferedReader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",", -1);
                rows.add(parts);
            }
        } catch (IOException e) {
            // ignore
        }

        PrintWriter out = resp.getWriter();
        out.println("<!doctype html><html><head><meta charset='utf-8'/><meta name='viewport' content='width=device-width,initial-scale=1'/><title>Students</title><link rel='stylesheet' href='/StudentCourseManagement/style.css'></head><body>");
        out.println("<div class='header'>EASWARI COLLEGE OF ENGINEERING - Student List</div><div class='container'>");
        out.println("<p><a href='/StudentCourseManagement/'>Home</a> | <a href='/StudentCourseManagement/students/add'>Add Student</a></p>");
        out.println("<table><thead><tr><th>#</th><th>Name</th><th>Roll</th><th>Department</th><th>Year</th><th>Actions</th></tr></thead><tbody>");
        if(rows.isEmpty()) {
            out.println("<tr><td colspan='6' class='empty'>No students yet.</td></tr>");
        } else {
            int i=1;
            for (String[] r : rows) {
                String name = r.length>0? r[0] : "";
                String roll = r.length>1? r[1] : "";
                String dept = r.length>2? r[2] : "";
                String year = r.length>3? r[3] : "";
                out.println("<tr>");
                out.println("<td>"+i+"</td>");
                out.println("<td>"+escape(name)+"</td>");
                out.println("<td>"+escape(roll)+"</td>");
                out.println("<td>"+escape(dept)+"</td>");
                out.println("<td>"+escape(year)+"</td>");
                out.println("<td><a href='/StudentCourseManagement/students/edit?roll="+encode(roll)+"'>Edit</a> | <a href='/StudentCourseManagement/students/delete?roll="+encode(roll)+"' onclick=\"return confirm('Delete?')\">Delete</a></td>");
                out.println("</tr>");
                i++;
            }
        }
        out.println("</tbody></table></div></body></html>");
    }

    private String escape(String s){ if(s==null) return ""; return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;"); }
    private String encode(String s){ if(s==null) return ""; return s.replaceAll(" ", "%20"); }
}

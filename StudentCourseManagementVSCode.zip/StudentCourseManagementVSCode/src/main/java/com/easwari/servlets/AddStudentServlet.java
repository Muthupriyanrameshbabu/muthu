package com.easwari.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.nio.file.*;

@WebServlet(name="AddStudentServlet", urlPatterns = {"/students/add"})
public class AddStudentServlet extends HttpServlet {

    private Path dataFile() throws IOException {
        Path webapp = Paths.get(getServletContext().getRealPath("/"));
        Path projRoot = webapp.getParent().getParent();
        Path p = projRoot.resolve("data").resolve("students.csv").normalize();
        if (!Files.exists(p)) {
            Files.createDirectories(p.getParent());
            Files.createFile(p);
        }
        return p;
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(req.getContextPath() + "/add_student.html"); // serve static form
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String name = req.getParameter("name");
        String roll = req.getParameter("roll");
        String dept = req.getParameter("department");
        String year = req.getParameter("year");

        if (name == null || roll == null) {
            resp.sendRedirect(req.getContextPath() + "/students"); return;
        }

        Path file = dataFile();
        String line = escapeCsv(name) + "," + escapeCsv(roll) + "," + escapeCsv(dept) + "," + escapeCsv(year) + System.lineSeparator();
        Files.write(file, line.getBytes("UTF-8"), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        resp.getWriter().write("<script>alert('Student added successfully');window.location='" + req.getContextPath() + "/students';</script>");
    }

    private String escapeCsv(String s){ if(s==null) return ""; return s.replaceAll(","," "); }
}
